E-Commerce Data - Customer Segmentation 

This is a transnational data set which contains all the transactions occurring between 01/12/2010 and 09/12/2011 for a UK-based and registered non-store online retail.The company mainly sells unique all-occasion gifts. Many customers of the company are wholesalers.

Customer Churn Analysis reveals regional customers' product sales and profits. Analytical users can use it to gain valuable insights on business growth across geographies and the distribution of profits among customers. They can receive extensive data by using the right visualizations and data structure. The project aims to include regional cash inflows and the customers' product-specific churn over time.

In the analysis overview page, you could use Combo Charts, Cards, Bar Charts, Tables, Line Charts; for the customer segmentation page, you could employ Column Charts, Bubble Charts, Point Maps, Tables, etc.