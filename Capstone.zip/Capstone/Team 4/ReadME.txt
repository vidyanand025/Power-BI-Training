Marketing Campaign Insights Analysis

https://github.com/nailson/ifood-data-business-analyst-test/blob/master/iFood%20Data%20Analyst%20Case.pdf 

The project idea is to showcase the efficacy of various marketing campaigns and the performance of product groups and platforms. This project is an excellent approach for a marketing manager to assess the success of marketing campaigns.

For the data visualization dashboard, you can explore many of the Power BI visualization types such as Bar Charts for category-wise expenditures, Column Charts for campaign success rate, Smart Narratives for displaying the key highlights of the campaign, Bubble Charts for customer-wise spending, Cards for showing individual data insights, etc.

================

The data set ifood_df.csv consists of 2206 customers of XYZ company with data on:

Customer profiles
Product preferences
Campaign successes/failures
Channel performance