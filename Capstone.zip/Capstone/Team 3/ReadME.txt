Healthcare Sales Analysis

The project idea is to enable those in the Animal Healthcare sector to efficiently track the sale of products dedicated to the treatment of minor animal species. Businesses may instantly compare product sales in the top-ranking cities and the bottom-ranking cities. The project could generate a thorough report on therapeutic group-wise sales and the sales trends for any specified time period.

For the data visualization on Power BI, you might use Tables for displaying the therapeutic group-wise sales; Column Charts for monthly sales trends; Bar charts for top and bottom-ranking cities; and also, you can include Treemaps, Cards, Smart Narratives, etc. 

========================================================
The dataset is built from the initial dataset consisted of 600000 transactional data collected in 6 years (period 2014-2019), indicating date and time of sale, pharmaceutical drug brand name and sold quantity, exported from Point-of-Sale system in the individual pharmacy. Selected group of drugs from the dataset (57 drugs) is classified to the following Anatomical Therapeutic Chemical (ATC) Classification System categories:

M01AB - Anti-inflammatory and antirheumatic products, non-steroids, Acetic acid derivatives and related substances
M01AE - Anti-inflammatory and antirheumatic products, non-steroids, Propionic acid derivatives
N02BA - Other analgesics and antipyretics, Salicylic acid and derivatives
N02BE/B - Other analgesics and antipyretics, Pyrazolones and Anilides
N05B - Psycholeptics drugs, Anxiolytic drugs
N05C - Psycholeptics drugs, Hypnotics and sedatives drugs
R03 - Drugs for obstructive airway diseases
R06 - Antihistamines for systemic use
Sales data are resampled to the hourly, daily, weekly and monthly periods. Data is already pre-processed, where processing included outlier detection and treatment and missing data imputation.